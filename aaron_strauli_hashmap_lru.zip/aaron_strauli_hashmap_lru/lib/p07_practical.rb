require_relative 'p05_hash_map'

def can_string_be_palindrome?(string)

end
